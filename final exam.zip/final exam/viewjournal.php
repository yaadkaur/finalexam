<?php
require_once('connect.php');
only_users();
require_once('header.php'); 
?>

<header>
			
				<h3>Add Journal</h3>
				<nav>
				<a href="addjournal.php">ADD NEW JOURNAL</a>
				<a href="viewjournal.php">VIEW JOURNAL HERE</a>
				<a href="logout.php">LOGOUT</a>
				</nav>
		
		</header>

			<br/>
			
			<?php
    try {
        require_once('connect.php');

        // Get all records from database

        $sql = "SELECT * FROM journalentry;";

        $statement = $db->prepare($sql);

        $statement->execute();

        $records = $statement->fetchAll(PDO::FETCH_ASSOC);

        echo "<table class='table'>";
		echo "<tr> <td> #</td> <td>Title</td> <td> Text </td> <td> Date</td> </tr>";
        // Print all records as an HTML table

        foreach ($records as $record) {
            echo "<tr>";
              foreach ($record as $key => $value) {
                echo "<td>";
                  echo $value;
                echo "</td>";
              }
              echo "<td>";
                echo "<a href='edit.php?id=" . $record['je_id'] . "' >Edit</a> &nbsp;";
                echo "<a  href='delete.php?id=" . $record['je_id'] . "'>Delete</a>";
              echo "</td>";
            echo "</tr>";

        }
        echo "</table>";

        $statement->closeCursor();
    }
    catch(PDOException $e) {
        $error_message = $e->getMessage();
        echo "<p> $error_message </p>";
    }
    ?>

<?php require_once('footer.php'); ?>
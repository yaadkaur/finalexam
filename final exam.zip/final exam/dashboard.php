<?php
require_once('connect.php');
only_users();
require_once('header.php'); 
?>

  <header>
    <div>
      <h3>Dashboard</h3>
      <nav>
        <a href="addjournal.php">ADD NEW JOURNAL</a>
        <a href="viewjournal.php">VIEW JOURNAL HERE</a>
        <a href="logout.php">LOGOUT</a>
      </nav>
    </div>
  </header>
<div>
			<p> Hello, <?=strtoupper($_SESSION["id"]["name"])?></p>	
		</div>
<?php require_once('footer.php'); ?>
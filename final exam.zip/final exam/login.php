<?php 
require "connect.php";
 if(isset($_SESSION['id'])){
        header('Location:dashboard.php');
    }
require "header.php"; 

if(isset($_POST["submit"])){
	$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
	$password = filter_input(INPUT_POST, 'password');

	$ok = true;

	if(empty($email)) $ok = false;
	if(empty($password)) $ok = false;

	if($ok === true){

		try{
	        $statement = $db->query("SELECT * FROM users WHERE email='$email';");
	        $user = $statement->fetch(PDO::FETCH_ASSOC);
	        if(!password_verify($password, $user["password"])){
	        	throw new Exception('Incorrect password.');
	        }else{
	        	$_SESSION["id"] = $user;
				
	        	header("Location: dashboard.php");
	        }
		}
		catch(Exception $e){
	        echo "<p>" . $e->getMessage() . "</p>";
		}

	}else{
		echo "<p>Please fill all the forms.</p>";
	}
}


?>

	<header>
			<h3>Login</h3>
			<nav>
				<a href="login.php">Login</a>
				<a href="register.php">Register</a>
			</nav>
		</div>
	</header>

	
		<?php
		if(isset($_GET["error"])){
		?>
		<div>
			You must login before accessing that page.
		</div>
		<?php
		}
		?>
		<form method="post">
			<div>
				<label>Email</label>
				<input type="text" name="email" />
			</div>
			<div>
				<label>Password</label>
				<input type="password" name="password" />
			</div>
			<div>
				<button type="submit"  name="submit">Login</button>
			</div>
		</form>
	</main>
<?php 
require "footer.php";
?>
<?php ob_start();

try {

    $id = filter_input(INPUT_GET, 0);

    require_once('connect.php');

    $sql = "DELETE FROM journalentry WHERE je_id = :JE_ID	;";

    $statement = $db->prepare($sql);

    $statement->bindParam(':JE_ID', $id );

    $statement->execute();

    $statement->closeCursor();

    header('location:viewjournal.php');
}
catch(PDOException $e) {
    $error_message = $e->getMessage();
    echo "<p> $error_message </p>";
}
ob_flush();
?>

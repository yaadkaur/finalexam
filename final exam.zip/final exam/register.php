	<?php 
	require "connect.php";
	 if(isset($_SESSION['id'])){
        header('Location:dashboard.php');
    }
	require "header.php"; 

	if(isset($_POST["submit"])){
		$name = filter_input(INPUT_POST, 'name');
		$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
		$password = filter_input(INPUT_POST, 'password');

		$ok = true;

		if(empty($name)) $ok = false;
		if(empty($email)) $ok = false;
		if(empty($password)) $ok = false;

		if($ok === true){

			try{
				$password = password_hash($password, PASSWORD_DEFAULT);
				$sql = "INSERT INTO users(name, email, password) VALUES(:NAME,:EMAIL,:PASSWORD)";
				$statement = $db->prepare($sql);
				$statement->bindParam(':NAME', $name);
				$statement->bindParam(':EMAIL', $email);
				$statement->bindParam(':PASSWORD', $password);
				$statement->execute();
				echo "<p>You have registered successfully.</p>";
				$statement->closeCursor();
			}
			catch(Exception $e){
				echo "<p>There was some problem. " . $e->getMessage() . "</p>";
			}

		}else{
			echo "Please fill all the forms.";
		}
	}


	?>

		<header>
			
				<h3>Registration</h3>
				<nav>
					<a href="login.php">Login</a>
					<a href="register.php">Register</a>
				</nav>
		
		</header>

	
			<form method="post">
				<div>
					<label>Name</label>
					<input type="text" name="name" />
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="text" name="email" />
				</div>
				<div>
					<label>Password</label>
					<input  type="password" name="password" />
				</div>
				<div class="form-group">
					<button type="submit" name="submit">Register</button>
				</div>
			</form>
		
	<?php 
	require "footer.php";
	?>
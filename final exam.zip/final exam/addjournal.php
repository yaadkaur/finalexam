<?php
require_once('connect.php');
only_users();
require_once('header.php'); 

if(isset($_POST["submit"])){
		$title = filter_input(INPUT_POST, 'title');
		$textbox = filter_input(INPUT_POST, 'textbox');
		$date = filter_input(INPUT_POST, 'date');

		$ok = true;

		if(empty($title)) $ok = false;
		if(empty($textbox)) $ok = false;
		if(empty($date)) $ok = false;

		if($ok === true){

			try{
				
				$sql = "INSERT INTO journalentry(je_title, je_text, je_date) VALUES(:TITLE,:TEXT,:DATE)";
				$statement = $db->prepare($sql);
				$statement->bindParam(':TITLE', $title);
				$statement->bindParam(':TEXT', $textbox);
				$statement->bindParam(':DATE', $date);
				$statement->execute();
				echo "<p>You journal is saved.</p>";
				$statement->closeCursor();
			}
			catch(Exception $e){
				echo "<p>There was some problem. " . $e->getMessage() . "</p>";
			}

		}else{
			echo "Please fill all the forms.";
		}
	}
?>



<header>
			
				<h3>Add Journal</h3>
				<nav>
				<a href="addjournal.php">ADD NEW JOURNAL</a>
				<a href="viewjournal.php">VIEW JOURNAL HERE</a>
				<a href="logout.php">LOGOUT</a>
				</nav>
		
		</header>

			<br/>
			<form method="post">
				<div>
					<label>Title</label>
					<input type="text" name="title" />
				</div>
				<div class="form-group">
					<label>Text</label>
					 <textarea name="textbox" rows="10" cols="30"></textarea>
				</div>
				<div>
					<label>Date</label>
					<input  type="date" name="date" />
				</div>
				<div class="form-group">
					<button type="submit" name="submit">Add</button>
				</div>
			</form>
<?php require_once('footer.php'); ?>
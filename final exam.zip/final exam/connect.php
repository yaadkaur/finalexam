<?php
try{
    // Connect to a database
    $dsn = 'mysql:host=localhost;dbname=finalExam';
    $username = 'root';
    $password = '';
    $db = new PDO($dsn, $username, $password);
    session_start();
  }
catch(PDOException $e) {
    // Incase there is an error connecting to database
    $error_message = $e->getMessage();
    echo "<p> UNABLE TO CONNECT!! IT IS THIS -  $error_message </p>";
}

//set error mode to exception
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function only_users(){
    if(!isset($_SESSION['id'])){
        header('Location:login.php?error=401');
    }
}
?>